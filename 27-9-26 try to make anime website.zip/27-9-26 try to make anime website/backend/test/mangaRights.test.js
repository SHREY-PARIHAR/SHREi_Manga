const test = require("node:test");
const assert = require("node:assert/strict");
const MangaChapter = require("../models/mangaChapter");
const { canReadChapter, canDownloadChapter } = require("../utils/mangaRights");

function verifiedChapter(overrides = {}) {
  return {
    sourceId: 123,
    chapterId: "chapter-1",
    chapterNumber: 1,
    title: "Chapter 1",
    contentSource: { name: "Authorized source", url: "https://publisher.example/manga" },
    rightsEvidence: {
      summary: "Written publication permission",
      url: "https://publisher.example/permission",
      verifiedAt: new Date(),
    },
    license: { name: "Publisher permission" },
    rightsStatus: "verified",
    publicationStatus: "published",
    permissions: { onlineReading: true, pdfDownload: false },
    pages: [{ pageNumber: 1, imageUrl: "https://cdn.example/page-1.webp" }],
    pdfUrl: "https://cdn.example/chapter-1.pdf",
    ...overrides,
  };
}

test("online reading requires verified, published rights and page permission", () => {
  assert.equal(canReadChapter(verifiedChapter()), true);
  assert.equal(canReadChapter(verifiedChapter({ rightsStatus: "unverified" })), false);
  assert.equal(canReadChapter(verifiedChapter({ publicationStatus: "draft" })), false);
  assert.equal(canReadChapter(verifiedChapter({ publicationStatus: "withdrawn" })), false);
  assert.equal(canReadChapter(verifiedChapter({ permissions: { onlineReading: false, pdfDownload: true } })), false);
  assert.equal(canReadChapter(verifiedChapter({ rightsEvidence: { summary: "", url: "", verifiedAt: null } })), false);
});

test("PDF downloads require separate PDF permission", () => {
  assert.equal(canDownloadChapter(verifiedChapter()), false);
  assert.equal(canDownloadChapter(verifiedChapter({
    permissions: { onlineReading: true, pdfDownload: true },
  })), true);
  assert.equal(canDownloadChapter(verifiedChapter({
    permissions: { onlineReading: false, pdfDownload: true },
    pages: [],
  })), true);
  assert.equal(canDownloadChapter(verifiedChapter({
    permissions: { onlineReading: false, pdfDownload: true },
    pdfUrl: "",
  })), false);
});

test("content and evidence references must use credential-free HTTPS", () => {
  assert.equal(canReadChapter(verifiedChapter({
    contentSource: { name: "Source", url: "https://user:secret@publisher.example/" },
  })), false);
  assert.equal(canDownloadChapter(verifiedChapter({
    rightsEvidence: { summary: "Evidence", url: "http://publisher.example/permission", verifiedAt: new Date() },
    permissions: { onlineReading: true, pdfDownload: true },
  })), false);
  assert.equal(canReadChapter(verifiedChapter({
    pages: [{ pageNumber: 1, imageUrl: "javascript:alert(1)" }],
  })), false);
});

test("new rights records default to unpublished and unverified", () => {
  const chapter = new MangaChapter({
    sourceId: 123,
    chapterId: "chapter-2",
    chapterNumber: 2,
    title: "Chapter 2",
    contentSource: { name: "Source", url: "https://publisher.example/manga" },
    rightsEvidence: { summary: "Pending review", url: "https://publisher.example/terms" },
    license: { name: "Pending rights review" },
  });
  assert.equal(chapter.rightsStatus, "unverified");
  assert.equal(chapter.publicationStatus, "draft");
  assert.equal(chapter.permissions.onlineReading, false);
  assert.equal(chapter.permissions.pdfDownload, false);
  assert.equal(canReadChapter(chapter), false);
  assert.equal(canDownloadChapter(chapter), false);
});
