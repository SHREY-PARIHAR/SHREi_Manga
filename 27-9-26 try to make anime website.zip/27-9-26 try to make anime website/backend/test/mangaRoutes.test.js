const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const express = require("express");
const mongoose = require("mongoose");
const mangaRoutes = require("../routes/mangaRoutes");

const mangaId = "e900135b-8eba-4d29-85c9-db3d5ae885c7";
const chapterId = "810c5fd7-59bc-46f6-b336-4f766d09f3d1";
const nextChapterId = "2f23751e-4b5e-4b40-9239-2f65ab92a1eb";
const scanlationGroupId = "50bc65ba-3e46-425c-a27f-2c6a8d397936";
const coverFile = "9a9fa7b3-df9a-4b74-970e-9853a40e2977.jpg";
const mangaTitle = {
  id: mangaId,
  type: "manga",
  attributes: {
    title: { en: "The Ghostly Doctor" },
    altTitles: [{ en: "Mesmerizing Ghost Doctor" }, { ru: "Призрачный доктор" }],
    description: { en: "A verified MangaDex metadata fixture." },
    originalLanguage: "zh",
    availableTranslatedLanguages: ["en"],
    status: "ongoing",
    year: 2017,
    lastChapter: "5",
    tags: [
      { attributes: { group: "genre", name: { en: "Action" } } },
      { attributes: { group: "format", name: { en: "Full Color" } } },
    ],
  },
  relationships: [
    { type: "cover_art", attributes: { fileName: coverFile } },
    { type: "author", attributes: { name: "Feng Jiong" } },
  ],
};

function feedChapter(id, chapter, groupName = "Read Manhua") {
  return {
    id,
    type: "chapter",
    attributes: { chapter, title: "", translatedLanguage: "en", pages: 2 },
    relationships: [
      { type: "scanlation_group", id: scanlationGroupId, attributes: { name: groupName } },
      { type: "manga", id: mangaId },
    ],
  };
}

const imageBytes = Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43]);
let server;
let baseUrl;
let priorFetch;
let priorRemovedIds;
let lastMangaQuery;
let emptyAtHomeResponse = false;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use("/api/manga", mangaRoutes);
  server = app.listen(0, "127.0.0.1");
  await new Promise((resolve, reject) => {
    server.once("listening", resolve);
    server.once("error", reject);
  });
  baseUrl = `http://127.0.0.1:${server.address().port}/api/manga`;
  priorFetch = global.fetch;
  priorRemovedIds = process.env.MANGADEX_REMOVED_CHAPTER_IDS;
  process.env.MANGADEX_REMOVED_CHAPTER_IDS = "";
  global.fetch = async (input) => {
    const url = new URL(String(input));
    if (url.hostname === "127.0.0.1" || url.hostname === "localhost") return priorFetch(input);
    if (url.hostname === "api.mangadex.org") {
      if (url.pathname === "/manga/tag") {
        return Response.json({
          result: "ok",
          data: [{ id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", attributes: { group: "genre", name: { en: "Action" } } }],
        });
      }
      if (url.pathname === "/manga") {
        lastMangaQuery = url.searchParams;
        const limit = Number(url.searchParams.get("limit")) || 15;
        return Response.json({ result: "ok", total: 15, data: Array(limit).fill(mangaTitle) });
      }
      if (url.pathname === `/manga/${mangaId}`) return Response.json({ result: "ok", data: mangaTitle });
      if (url.pathname === `/manga/${mangaId}/feed`) {
        return Response.json({
          result: "ok",
          total: 2,
          data: [feedChapter(chapterId, "0"), feedChapter(nextChapterId, "1")],
        });
      }
      if (url.pathname === `/at-home/server/${chapterId}` || url.pathname === `/at-home/server/${nextChapterId}`) {
        if (emptyAtHomeResponse) {
          return Response.json({
            result: "ok",
            baseUrl: "https://test.mangadex.network",
            chapter: { hash: "", data: [], dataSaver: [] },
          });
        }
        return Response.json({
          result: "ok",
          baseUrl: "https://test.mangadex.network/temporary-token",
          chapter: {
            hash: "4182f3b2ded076ac7b271ffaaec1d2ef",
            data: ["page-1.jpg", "page-2.jpg"],
          },
        });
      }
    }
    if (url.hostname === "test.mangadex.network") {
      throw Object.assign(new Error("Untrusted fixture CDN certificate"), {
        cause: { code: "UNABLE_TO_VERIFY_LEAF_SIGNATURE" },
      });
    }
    if (url.hostname === "uploads.mangadex.org") {
      return new Response(imageBytes, { headers: { "Content-Type": "image/jpeg" } });
    }
    throw new Error(`Unexpected test URL: ${url.href}`);
  };
});

after(async () => {
  global.fetch = priorFetch;
  if (priorRemovedIds === undefined) delete process.env.MANGADEX_REMOVED_CHAPTER_IDS;
  else process.env.MANGADEX_REMOVED_CHAPTER_IDS = priorRemovedIds;
  if (server) await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
});

test("MangaDex catalogue requests the configured page size without requiring MongoDB", async () => {
  assert.notEqual(mongoose.connection.readyState, 1);
  const response = await fetch(`${baseUrl}?page=1&perPage=15`);
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.equal(result.data.length, 15);
  assert.equal(result.data[0].sourceId, mangaId);
  assert.equal(result.data[0].title, "The Ghostly Doctor");
  assert.equal(result.data[0].poster, `/manga/${mangaId}/cover/${coverFile}`);
  assert.equal(result.pagination.total, 15);
});

test("MangaDex search, genre, status, year, and sort filters are passed to the official API", async () => {
  const response = await fetch(`${baseUrl}?perPage=10&search=Frieren&genre=Action&year=2017&status=Ongoing&sort=popular`);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).data.length, 10);
  assert.equal(lastMangaQuery.get("title"), "Frieren");
  assert.equal(lastMangaQuery.get("includedTags[]"), "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa");
  assert.equal(lastMangaQuery.get("year"), "2017");
  assert.equal(lastMangaQuery.get("status[]"), "ongoing");
  assert.equal(lastMangaQuery.get("order[followedCount]"), "desc");
  const hiatusResponse = await fetch(`${baseUrl}?perPage=10&status=On%20hiatus`);
  assert.equal(hiatusResponse.status, 200);
  assert.equal(lastMangaQuery.get("status[]"), "hiatus");
});

test("MangaDex manga details preserve UUIDs, authors, alternate titles, and cover routes", async () => {
  const response = await fetch(`${baseUrl}/${mangaId}`);
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.equal(result.data.sourceId, mangaId);
  assert.deepEqual(result.data.authors, ["Feng Jiong"]);
  assert.deepEqual(result.data.alternateTitles, ["Mesmerizing Ghost Doctor"]);
  assert.equal(result.data.alternateTitles.some((title) => /Призрачный/.test(title)), false);
  assert.equal(result.data.colorMode, "color");
  assert.equal(result.data.latestChapter, "5");
});

test("MangaDex cover image is delivered through SHREI's backend proxy", async () => {
  const response = await fetch(`${baseUrl}/${mangaId}/cover/${coverFile}`);
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("content-type"), "image/jpeg");
  assert.deepEqual(Buffer.from(await response.arrayBuffer()), imageBytes);
});

test("chapter list credits the scanlation group and never claims unverified pages are readable", async () => {
  const response = await fetch(`${baseUrl}/${mangaId}/chapters`);
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.equal(result.data.length, 2);
  assert.equal(result.data[0].groupName, "Read Manhua");
  assert.equal(result.data[0].groupUrl, `https://mangadex.org/group/${scanlationGroupId}`);
  assert.equal(result.data[0].canRead, false);
  assert.equal(result.data[0].verificationRequired, true);
});

test("chapter verification checks a real page and supplies sequential chapter navigation", async () => {
  const response = await fetch(`${baseUrl}/${mangaId}/chapters/${nextChapterId}`);
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.equal(result.data.canRead, true);
  assert.equal(result.data.verificationStatus, "first-page-verified");
  assert.equal(result.data.firstPage.bytes, imageBytes.length);
  assert.equal(result.data.previousChapterId, chapterId);
  assert.equal(result.data.nextChapterId, null);
  assert.equal(result.data.credits.provider, "MangaDex");
  assert.equal(result.data.credits.groupName, "Read Manhua");
  assert.equal(result.data.canDownload, false);
  assert.equal(result.data.pages[0].imagePath, `/manga/${mangaId}/chapters/${nextChapterId}/pages/1`);
  const downloadResponse = await fetch(`${baseUrl}/${mangaId}/chapters/${nextChapterId}/download`);
  assert.equal(downloadResponse.status, 404);
});

test("chapters without MangaDex pages are reported as unavailable rather than retryable", async () => {
  emptyAtHomeResponse = true;
  try {
    const response = await fetch(`${baseUrl}/${mangaId}/chapters/${chapterId}`);
    assert.equal(response.status, 404);
    assert.deepEqual(await response.json(), {
      success: false,
      code: "MANGADEX_CHAPTER_PAGES_UNAVAILABLE",
      message: "This chapter has no pages available on MangaDex.",
    });
  } finally {
    emptyAtHomeResponse = false;
  }
});

test("MangaDex chapter pages stream through the backend and untrusted @Home TLS uses only the verified uploads host", async () => {
  const response = await fetch(`${baseUrl}/${mangaId}/chapters/${chapterId}/pages/2`);
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("content-type"), "image/jpeg");
  assert.equal(response.headers.get("x-content-type-options"), "nosniff");
  assert.deepEqual(Buffer.from(await response.arrayBuffer()), imageBytes);
});

test("MangaDex removal list blocks chapter metadata and page access", async () => {
  process.env.MANGADEX_REMOVED_CHAPTER_IDS = chapterId;
  const listResponse = await fetch(`${baseUrl}/${mangaId}/chapters`);
  assert.equal((await listResponse.json()).data.length, 1);
  const pageResponse = await fetch(`${baseUrl}/${mangaId}/chapters/${chapterId}/pages/1`);
  assert.equal(pageResponse.status, 410);
});

test("MangaDex API rate limits are surfaced with Retry-After", async (t) => {
  const fetchBefore = global.fetch;
  global.fetch = async (input) => {
    const url = new URL(String(input));
    if (url.hostname === "127.0.0.1" || url.hostname === "localhost") return fetchBefore(input);
    return new Response("{}", { status: 429, headers: { "Retry-After": "3" } });
  };
  t.after(() => { global.fetch = fetchBefore; });
  const response = await fetch(`${baseUrl}?perPage=15`);
  assert.equal(response.status, 429);
  assert.equal(response.headers.get("retry-after"), "3");
  const result = await response.json();
  assert.match(result.message, /rate limiting/i);
  assert.equal(result.code, "MANGADEX_RATE_LIMITED");
});

test("MangaDex connection failures expose the exact safe transport error code", async (t) => {
  const fetchBefore = global.fetch;
  let upstreamAttempts = 0;
  global.fetch = async (input) => {
    const url = new URL(String(input));
    if (url.hostname === "127.0.0.1" || url.hostname === "localhost") return fetchBefore(input);
    upstreamAttempts += 1;
    throw Object.assign(new Error("fetch failed"), { cause: { code: "UND_ERR_SOCKET" } });
  };
  t.after(() => { global.fetch = fetchBefore; });
  const response = await fetch(`${baseUrl}?perPage=15&page=4`);
  const result = await response.json();
  assert.equal(response.status, 502);
  assert.equal(result.code, "UND_ERR_SOCKET");
  assert.match(result.message, /MangaDex connection failed \(UND_ERR_SOCKET\)/);
  assert.equal(upstreamAttempts, 2);
});
