const mongoose = require("mongoose");

const httpsUrl = {
  validator(value) {
    if (!value) return true;
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password;
    } catch {
      return false;
    }
  },
  message: "Content references must be credential-free HTTPS URLs.",
};

const mangaChapterSchema = new mongoose.Schema(
  {
    sourceId: { type: Number, required: true, index: true },
    chapterId: { type: String, required: true, trim: true },
    chapterNumber: { type: Number, required: true, min: 0, validate: Number.isFinite },
    title: { type: String, required: true, trim: true },
    contentSource: {
      name: { type: String, required: true, trim: true },
      url: { type: String, required: true, trim: true, validate: httpsUrl },
    },
    rightsEvidence: {
      summary: { type: String, required: true, trim: true },
      url: { type: String, required: true, trim: true, validate: httpsUrl },
      verifiedAt: { type: Date },
    },
    license: {
      name: { type: String, required: true, trim: true },
      url: { type: String, trim: true, default: "", validate: httpsUrl },
      restrictions: { type: String, trim: true, default: "" },
    },
    rightsStatus: {
      type: String,
      enum: ["unverified", "verified", "revoked"],
      default: "unverified",
    },
    permissions: {
      onlineReading: { type: Boolean, default: false },
      pdfDownload: { type: Boolean, default: false },
    },
    publicationStatus: {
      type: String,
      enum: ["draft", "published", "withdrawn"],
      default: "draft",
    },
    colorMode: {
      type: String,
      enum: ["color", "black-and-white", "unknown"],
      default: "unknown",
    },
    pages: {
      type: [
        {
          pageNumber: { type: Number, required: true, min: 1 },
          imageUrl: { type: String, required: true, trim: true, select: false, validate: httpsUrl },
        },
      ],
      default: [],
    },
    pdfUrl: { type: String, trim: true, default: "", select: false, validate: httpsUrl },
  },
  { timestamps: true }
);

mangaChapterSchema.index({ sourceId: 1, chapterId: 1 }, { unique: true });
mangaChapterSchema.index({ sourceId: 1, chapterNumber: 1 });

module.exports = mongoose.model("MangaChapter", mangaChapterSchema);
