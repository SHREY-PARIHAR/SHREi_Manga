const mongoose = require("mongoose");

const mangaSchema = new mongoose.Schema(
  {
    sourceId: { type: Number, required: true, unique: true },
    title: { type: String, required: true, trim: true },
    alternateTitles: { type: [String], default: [] },
    description: { type: String, default: "" },
    poster: { type: String, default: "" },
    banner: { type: String, default: "" },
    genres: { type: [String], default: [] },
    authors: { type: [String], default: [] },
    format: { type: String, default: "" },
    status: { type: String, default: "Unknown" },
    year: { type: Number },
    chapters: { type: Number, default: 0 },
    volumes: { type: Number, default: 0 },
    rating: { type: Number, default: 0 },
    popularity: { type: Number, default: 0 },
    colorMode: {
      type: String,
      enum: ["color", "black-and-white", "unknown"],
      default: "unknown",
    },
    adaptations: {
      type: [
        {
          sourceId: Number,
          type: { type: String, enum: ["ANIME", "MANGA"] },
          title: String,
          relation: String,
        },
      ],
      default: [],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Manga", mangaSchema);
