const mongoose = require("mongoose");

const animeCatalogPageSchema = new mongoose.Schema({
  page: {
    type: Number,
    required: true,
  },
  perPage: {
    type: Number,
    required: true,
  },
  search: {
    type: String,
    default: "",
  },
  genre: {
    type: String,
    default: "",
  },
  year: {
    type: Number,
    default: 0,
  },
  status: {
    type: String,
    default: "",
  },
  sort: {
    type: String,
    default: "popular",
  },
  sourceIds: {
    type: [Number],
    default: [],
  },
  total: {
    type: Number,
    required: true,
  },
  hasNextPage: {
    type: Boolean,
    required: true,
  },
  cachedAt: {
    type: Date,
    required: true,
  },
});

animeCatalogPageSchema.index(
  { page: 1, perPage: 1, search: 1, genre: 1, year: 1, status: 1, sort: 1 },
  { unique: true }
);

module.exports = mongoose.model("AnimeCatalogPage", animeCatalogPageSchema);