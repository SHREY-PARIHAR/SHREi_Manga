const mongoose = require("mongoose");

const officialProviderSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    url: { type: String, required: true, trim: true },
    accessType: { type: String, enum: ["official"], default: "official" },
  },
  { _id: false }
);

const playbackSourceSchema = new mongoose.Schema(
  {
    episodeNumber: { type: Number, required: true, min: 1, validate: Number.isInteger },
    kind: { type: String, enum: ["direct-media"], required: true },
    authorizationStatus: { type: String, enum: ["authorized"], required: true },
    url: {
      type: String,
      required: true,
      trim: true,
      validate: {
        validator(value) {
          try {
            const url = new URL(value);
            return url.protocol === "https:" && !url.username && !url.password;
          } catch {
            return false;
          }
        },
        message: "Playback source URLs must use HTTPS and cannot include credentials.",
      },
    },
    mimeType: {
      type: String,
      enum: [
        "video/mp4",
        "video/webm",
        "video/ogg",
        "application/vnd.apple.mpegurl",
        "application/x-mpegurl",
      ],
      required: true,
    },
  },
  { _id: false }
);

const animeSchema = new mongoose.Schema(
  {
    sourceId: {
      type: Number,
      unique: true,
      sparse: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },

    description: {
      type: String,
      default: "",
    },

    poster: {
      type: String,
      default: "",
    },

    banner: {
      type: String,
      default: "",
    },

    studio: {
      type: String,
      default: "",
    },

    season: {
      type: String,
      default: "Unknown",
    },

    genres: {
      type: [String],
      default: [],
    },

    language: {
      type: [String],
      default: [],
    },

    type: {
      type: String,
      enum: ["Series", "Movie"],
      default: "Series",
    },

    year: {
      type: Number,
    },

    status: {
      type: String,
      enum: ["Ongoing", "Completed", "Upcoming"],
      default: "Ongoing",
    },

    totalEpisodes: {
      type: Number,
      default: 0,
    },

    rating: {
      type: Number,
      default: 0,
    },

    popularity: {
      type: Number,
      default: 0,
    },

    featured: {
      type: Boolean,
      default: false,
    },
    officialProviders: {
      type: [officialProviderSchema],
      default: [],
    },
    adaptations: {
      type: [
        {
          sourceId: Number,
          type: { type: String, enum: ["ANIME", "MANGA"] },
          title: String,
          relation: String,
        },
      ],
      default: [],
    },
    playbackSources: {
      type: [playbackSourceSchema],
      default: [],
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Anime", animeSchema);