const API_BASE = "https://api.mangadex.org";
const USER_AGENT = "SHREI/1.0 (MangaDex integration)";
const REQUEST_TIMEOUT_MS = 15000;
const MAX_JSON_BYTES = 8 * 1024 * 1024;
const TLS_ERRORS = new Set([
  "CERT_HAS_EXPIRED",
  "DEPTH_ZERO_SELF_SIGNED_CERT",
  "ERR_TLS_CERT_ALTNAME_INVALID",
  "SELF_SIGNED_CERT_IN_CHAIN",
  "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
  "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
]);
const RETRYABLE_SOCKET_ERRORS = new Set(["UND_ERR_SOCKET", "ECONNRESET"]);

async function fetchWithSocketRetry(url, options) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      return await fetch(url, options);
    } catch (error) {
      const causeCode = error.cause?.code || error.code;
      if (attempt === 0 && RETRYABLE_SOCKET_ERRORS.has(causeCode)) {
        await new Promise((resolve) => setTimeout(resolve, 250));
        continue;
      }
      throw error;
    }
  }
  throw new Error("MangaDex request retry did not complete.");
}

class MangaDexError extends Error {
  constructor(message, { status = 502, code = "MANGADEX_UPSTREAM_ERROR", retryAfter = null } = {}) {
    super(message);
    this.name = "MangaDexError";
    this.status = status;
    this.code = code;
    this.retryAfter = retryAfter;
  }
}

function upstreamError(error) {
  const causeCode = error.cause?.code || error.code;
  if (TLS_ERRORS.has(causeCode)) {
    return new MangaDexError(
      `MangaDex TLS verification failed (${causeCode}). Check the local trusted certificate chain.`,
      { code: causeCode }
    );
  }
  if (error.name === "TimeoutError" || causeCode === "ETIMEDOUT" || causeCode === "UND_ERR_CONNECT_TIMEOUT") {
    return new MangaDexError("MangaDex request timed out.", { status: 504, code: "MANGADEX_TIMEOUT" });
  }
  if (causeCode === "UND_ERR_SOCKET" || causeCode === "ECONNRESET") {
    return new MangaDexError(`MangaDex connection failed (${causeCode}). Check the local network connection.`, {
      status: 502,
      code: causeCode,
    });
  }
  return error instanceof MangaDexError
    ? error
    : new MangaDexError("MangaDex is temporarily unavailable.", {
      code: /^[A-Z0-9_]+$/i.test(causeCode || "") ? causeCode : "MANGADEX_NETWORK_ERROR",
    });
}

async function getJson(path, params = {}) {
  const url = new URL(path, API_BASE);
  for (const [name, value] of Object.entries(params)) {
    if (Array.isArray(value)) value.forEach((entry) => url.searchParams.append(name, entry));
    else if (value !== undefined && value !== null && value !== "") url.searchParams.set(name, String(value));
  }

  let response;
  try {
    response = await fetchWithSocketRetry(url, {
      headers: { Accept: "application/json", "User-Agent": USER_AGENT },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch (error) {
    throw upstreamError(error);
  }
  if (!response.ok) {
    const retryAfter = response.headers.get("retry-after");
    throw new MangaDexError(
      response.status === 429 ? "MangaDex is rate limiting requests. Please retry shortly." : "MangaDex could not complete the request.",
      {
        status: response.status === 429 ? 429 : response.status >= 500 ? 502 : response.status,
        code: response.status === 429 ? "MANGADEX_RATE_LIMITED" : `MANGADEX_HTTP_${response.status}`,
        retryAfter,
      }
    );
  }
  const contentLength = Number(response.headers.get("content-length"));
  if (Number.isFinite(contentLength) && contentLength > MAX_JSON_BYTES) {
    throw new MangaDexError("MangaDex returned an oversized response.", { status: 502, code: "MANGADEX_RESPONSE_TOO_LARGE" });
  }
  let data;
  try {
    data = await response.json();
  } catch {
    throw new MangaDexError("MangaDex returned invalid JSON.", { status: 502, code: "MANGADEX_INVALID_RESPONSE" });
  }
  if (data?.result !== "ok") {
    throw new MangaDexError("MangaDex returned an unsuccessful response.", { status: 502, code: "MANGADEX_INVALID_RESPONSE" });
  }
  return data;
}

function isTlsVerificationError(error) {
  return TLS_ERRORS.has(error.cause?.code || error.code);
}

module.exports = { MangaDexError, fetchWithSocketRetry, getJson, isTlsVerificationError, upstreamError };
