const fs = require("fs");
const https = require("https");
const tls = require("tls");

const ENDPOINT = "https://graphql.anilist.co";
const REQUEST_TIMEOUT_MS = 15000;
const MAX_RESPONSE_BYTES = 5 * 1024 * 1024;
const TLS_FAILURES = new Set([
  "CERT_HAS_EXPIRED",
  "DEPTH_ZERO_SELF_SIGNED_CERT",
  "ERR_TLS_CERT_ALTNAME_INVALID",
  "SELF_SIGNED_CERT_IN_CHAIN",
  "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
  "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
]);

function trustedCertificates() {
  const certificates = [
    ...tls.getCACertificates("default"),
    ...tls.getCACertificates("system"),
  ];
  const configuredPath = process.env.ANILIST_CA_FILE;
  if (configuredPath) {
    let certificate;
    try {
      certificate = fs.readFileSync(configuredPath, "utf8");
      tls.createSecureContext({ ca: certificate });
    } catch {
      const error = new Error("ANILIST_CA_FILE must point to a readable PEM certificate bundle.");
      error.code = "ANILIST_CA_CONFIG";
      throw error;
    }
    certificates.push(certificate);
  }
  return [...new Set(certificates)];
}

function asProviderError(error) {
  if (TLS_FAILURES.has(error.code)) {
    const trustedRootError = new Error(
      "AniList TLS verification failed. Configure a trusted network CA using ANILIST_CA_FILE."
    );
    trustedRootError.code = "ANILIST_TLS_UNTRUSTED";
    return trustedRootError;
  }
  return error;
}

function requestAniList(query, variables = {}) {
  let certificates;
  try {
    certificates = trustedCertificates();
  } catch (error) {
    return Promise.reject(error);
  }

  const body = Buffer.from(JSON.stringify({ query, variables }));
  return new Promise((resolve, reject) => {
    const request = https.request(ENDPOINT, {
      method: "POST",
      ca: certificates,
      rejectUnauthorized: true,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Content-Length": body.length,
      },
      timeout: REQUEST_TIMEOUT_MS,
    }, (response) => {
      const chunks = [];
      let received = 0;
      response.on("data", (chunk) => {
        received += chunk.length;
        if (received > MAX_RESPONSE_BYTES) {
          response.destroy();
          reject(Object.assign(new Error("AniList response exceeded the size limit."), { code: "ANILIST_RESPONSE_TOO_LARGE" }));
          return;
        }
        chunks.push(chunk);
      });
      response.on("error", (error) => reject(asProviderError(error)));
      response.on("end", () => {
        let result;
        try {
          result = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        } catch {
          reject(Object.assign(new Error("AniList returned an invalid response."), { code: "ANILIST_INVALID_RESPONSE" }));
          return;
        }
        if (!result || typeof result !== "object"
          || response.statusCode < 200 || response.statusCode >= 300
          || result.errors?.length || !result.data) {
          reject(Object.assign(new Error("AniList request failed."), { code: "ANILIST_REQUEST_FAILED" }));
          return;
        }
        resolve(result.data);
      });
    });

    request.on("timeout", () => {
      request.destroy(Object.assign(new Error("AniList request timed out."), { code: "ANILIST_TIMEOUT" }));
    });
    request.on("error", (error) => reject(asProviderError(error)));
    request.end(body);
  });
}

module.exports = requestAniList;
