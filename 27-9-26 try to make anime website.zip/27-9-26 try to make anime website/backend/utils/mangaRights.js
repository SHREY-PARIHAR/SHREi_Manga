function validHttpsReference(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password;
  } catch {
    return false;
  }
}

function hasVerifiedRights(chapter) {
  return Boolean(
    chapter
      && chapter.rightsStatus === "verified"
      && chapter.publicationStatus === "published"
      && chapter.contentSource?.name
      && validHttpsReference(chapter.contentSource?.url)
      && chapter.rightsEvidence?.summary
      && validHttpsReference(chapter.rightsEvidence?.url)
      && chapter.rightsEvidence?.verifiedAt
      && chapter.license?.name
  );
}

function canReadChapter(chapter) {
  return Boolean(
    hasVerifiedRights(chapter)
      && chapter.publicationStatus === "published"
      && chapter.permissions?.onlineReading === true
      && Array.isArray(chapter.pages)
      && chapter.pages.length > 0
      && chapter.pages.every((page) => page.pageNumber > 0 && validHttpsReference(page.imageUrl))
  );
}

function canDownloadChapter(chapter) {
  return Boolean(
    hasVerifiedRights(chapter)
      && chapter.publicationStatus === "published"
      && chapter.permissions?.pdfDownload === true
      && validHttpsReference(chapter.pdfUrl)
  );
}

module.exports = { hasVerifiedRights, canReadChapter, canDownloadChapter };
