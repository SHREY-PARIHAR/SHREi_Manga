const mongoose = require("mongoose");

const connectDB = async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error("MongoDB connection failed: MONGODB_URI is not configured");
    return false;
  }

  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 8000 });
    console.log("MongoDB connected successfully");
    return true;
  } catch (error) {
    console.error("MongoDB connection failed:", error.code || error.cause?.code || error.name || "connection error");
    for (const server of error.reason?.servers?.values() || []) {
      const cause = server.error;
      if (cause) console.error("MongoDB node connection failed:", cause.code || cause.name || "connection failed");
    }
    return false;
  }
};

module.exports = connectDB;