const express = require("express");
const { Readable, Transform } = require("stream");
const { pipeline } = require("stream/promises");
const { MangaDexError, fetchWithSocketRetry, getJson, isTlsVerificationError, upstreamError } = require("../utils/mangaDexClient");

const router = express.Router();
const MANGADEX_WEB = "https://mangadex.org";
const UPLOADS_BASE = "https://uploads.mangadex.org";
const PAGE_MAX_BYTES = 25 * 1024 * 1024;
const PAGE_CACHE_TTL_MS = 14 * 60 * 1000;
const PAGE_REFERENCES = new Map();
let genreCache = { expiresAt: 0, genres: [], idsByName: new Map() };

function validUuid(value) {
  return typeof value === "string"
    && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function removedChapterIds() {
  return new Set(
    (process.env.MANGADEX_REMOVED_CHAPTER_IDS || "")
      .split(",")
      .map((id) => id.trim().toLowerCase())
      .filter(validUuid)
  );
}

function localizedText(values, preferred = ["en"]) {
  if (!values || typeof values !== "object") return "";
  for (const language of preferred) {
    if (typeof values[language] === "string" && values[language].trim()) return values[language].trim();
  }
  return Object.values(values).find((value) => typeof value === "string" && value.trim())?.trim() || "";
}

function mapManga(item, index = 0) {
  const attributes = item.attributes || {};
  const relationships = item.relationships || [];
  const tags = attributes.tags || [];
  const cover = relationships.find((relationship) => relationship.type === "cover_art")?.attributes?.fileName;
  const authors = relationships
    .filter((relationship) => relationship.type === "author" || relationship.type === "artist")
    .map((relationship) => relationship.attributes?.name)
    .filter(Boolean);
  const genres = tags
    .filter((tag) => tag.attributes?.group === "genre")
    .map((tag) => localizedText(tag.attributes?.name))
    .filter(Boolean);
  const format = tags
    .filter((tag) => tag.attributes?.group === "format")
    .map((tag) => localizedText(tag.attributes?.name))
    .find(Boolean) || "Unknown";
  const tagNames = tags.map((tag) => localizedText(tag.attributes?.name).toLowerCase());
  const colorMode = tagNames.includes("full color") || tagNames.includes("full colour")
    ? "color"
    : tagNames.includes("monochrome") || tagNames.includes("black and white")
      ? "black-and-white"
      : "unknown";

  return {
    sourceId: item.id,
    title: localizedText(attributes.title),
    alternateTitles: [...new Set((attributes.altTitles || [])
      .map((title) => typeof title.en === "string" ? title.en.trim() : "")
      .filter((title) => title && title !== localizedText(attributes.title)))],
    description: localizedText(attributes.description),
    poster: validUuid(item.id) && /^[\w.-]+$/.test(cover || "")
      ? `/manga/${item.id}/cover/${encodeURIComponent(cover)}`
      : "",
    banner: "",
    genres,
    authors: [...new Set(authors)],
    format,
    status: {
      ongoing: "Ongoing",
      completed: "Completed",
      hiatus: "On hiatus",
      cancelled: "Cancelled",
    }[attributes.status] || "Unknown",
    year: attributes.year || "N/A",
    latestChapter: attributes.lastChapter || "",
    latestVolume: attributes.lastVolume || "",
    originalLanguage: attributes.originalLanguage || "",
    rating: 0,
    popularity: Number(attributes.followedCount) || 0,
    colorMode,
    adaptations: [],
    availableTranslatedLanguages: attributes.availableTranslatedLanguages || [],
    paletteIndex: index,
  };
}

function mapChapter(item) {
  const attributes = item.attributes || {};
  const group = (item.relationships || []).find((relationship) => relationship.type === "scanlation_group");
  return {
    chapterId: item.id,
    chapterNumber: attributes.chapter || "Oneshot",
    title: attributes.title || "",
    volume: attributes.volume || "",
    language: attributes.translatedLanguage || "",
    pageCount: Number(attributes.pages) || 0,
    colorMode: "unknown",
    groupId: group?.id || "",
    groupName: group?.attributes?.name || "Unassigned MangaDex upload",
    groupUrl: validUuid(group?.id) ? `${MANGADEX_WEB}/group/${group.id}` : MANGADEX_WEB,
    canRead: false,
    verificationRequired: true,
    canDownload: false,
  };
}

function sendError(res, error, operation) {
  const upstream = error instanceof MangaDexError ? error : upstreamError(error);
  console.error(`${operation} failed:`, upstream.code);
  if (upstream.retryAfter) res.setHeader("Retry-After", upstream.retryAfter);
  return res.status(upstream.status).json({
    success: false,
    code: upstream.code,
    message: upstream.message,
    ...(upstream.code === "MANGADEX_RATE_LIMITED" ? { retryAfter: upstream.retryAfter } : {}),
  });
}

function normalizeSort(sort) {
  if (sort === "rating") return { "order[rating]": "desc" };
  if (sort === "latest") return { "order[latestUploadedChapter]": "desc" };
  if (sort === "az") return { "order[title]": "asc" };
  if (sort === "popular") return { "order[followedCount]": "desc" };
  return {};
}

async function getGenres() {
  if (genreCache.expiresAt > Date.now()) return genreCache;
  const response = await getJson("/manga/tag", { limit: 100 });
  const genreTags = (response.data || [])
    .filter((tag) => tag.attributes?.group === "genre" && tag.attributes?.name?.en)
    .map((tag) => ({ id: tag.id, name: tag.attributes.name.en }));
  const idsByName = new Map(genreTags.map((tag) => [tag.name.toLowerCase(), tag.id]));
  genreCache = {
    expiresAt: Date.now() + 10 * 60 * 1000,
    genres: genreTags.map((tag) => tag.name).sort((a, b) => a.localeCompare(b)),
    idsByName,
  };
  return genreCache;
}

function removed(id) {
  return removedChapterIds().has(id.toLowerCase());
}

async function fetchChapterFeed(mangaId) {
  const response = await getJson(`/manga/${mangaId}/feed`, {
    limit: 500,
    offset: 0,
    "translatedLanguage[]": ["en"],
    "contentRating[]": ["safe"],
    "includes[]": ["scanlation_group"],
    "order[chapter]": "asc",
    "order[volume]": "asc",
  });
  const filtered = (response.data || [])
    .filter((chapter) => !removed(chapter.id))
    .map(mapChapter);
  return {
    data: filtered,
    total: Number(response.total) || 0,
    limit: 500,
    hasMore: Number(response.total) > 500,
  };
}

function validAtHomeUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:"
      && !url.username && !url.password
      && (url.hostname.endsWith(".mangadex.network") || url.hostname === "uploads.mangadex.org");
  } catch {
    return false;
  }
}

async function getAtHome(mangaId, chapterId) {
  if (!validUuid(mangaId) || !validUuid(chapterId) || removed(chapterId)) {
    throw new MangaDexError("This MangaDex chapter is unavailable.", { status: 404, code: "MANGADEX_CHAPTER_UNAVAILABLE" });
  }
  const cached = PAGE_REFERENCES.get(chapterId);
  if (cached && cached.expiresAt > Date.now() && cached.mangaId === mangaId) return cached;

  const response = await getJson(`/at-home/server/${chapterId}`, { forcePort443: true });
  if (response.chapter?.hash === ""
    && Array.isArray(response.chapter?.data)
    && response.chapter.data.length === 0) {
    throw new MangaDexError("This chapter has no pages available on MangaDex.", {
      status: 404,
      code: "MANGADEX_CHAPTER_PAGES_UNAVAILABLE",
    });
  }
  if (!validAtHomeUrl(response.baseUrl)
    || !/^[a-f0-9]{32}$/i.test(response.chapter?.hash || "")
    || !Array.isArray(response.chapter?.data)
    || response.chapter.data.length < 1
    || response.chapter.data.length > 500) {
    throw new MangaDexError("MangaDex did not provide a valid chapter page list.", { status: 502, code: "MANGADEX_INVALID_CHAPTER_PAGES" });
  }
  const files = response.chapter.data.filter((file) => /^[\w.-]+$/.test(file));
  if (files.length !== response.chapter.data.length) {
    throw new MangaDexError("MangaDex returned invalid page references.", { status: 502, code: "MANGADEX_INVALID_CHAPTER_PAGES" });
  }
  const source = {
    mangaId,
    chapterId,
    baseUrl: response.baseUrl,
    hash: response.chapter.hash,
    files,
    expiresAt: Date.now() + PAGE_CACHE_TTL_MS,
  };
  PAGE_REFERENCES.set(chapterId, source);
  return source;
}

function imageUrls(source, filename) {
  const base = new URL(source.baseUrl);
  const dataPath = `data/${source.hash}/${encodeURIComponent(filename)}`;
  const primary = new URL(dataPath, base.href.endsWith("/") ? base : `${base.href}/`);
  const fallback = new URL(dataPath, `${UPLOADS_BASE}/`);
  return { primary, fallback };
}

async function fetchChapterImage(source, filename) {
  const { primary, fallback } = imageUrls(source, filename);
  try {
    const response = await fetchWithSocketRetry(primary, {
      headers: { Accept: "image/avif,image/webp,image/png,image/jpeg", "User-Agent": "SHREI/1.0 (MangaDex integration)" },
      redirect: "error",
      signal: AbortSignal.timeout(20000),
    });
    if (response.ok) return response;
    if (response.status === 429) {
      throw new MangaDexError("MangaDex is rate limiting chapter images. Please retry shortly.", {
        status: 429,
        code: "MANGADEX_RATE_LIMITED",
        retryAfter: response.headers.get("retry-after"),
      });
    }
    throw new MangaDexError("The MangaDex chapter image could not be loaded.", { status: 502, code: `MANGADEX_IMAGE_HTTP_${response.status}` });
  } catch (error) {
    if (!isTlsVerificationError(error)) throw upstreamError(error);
    if (!primary.hostname.endsWith(".mangadex.network")) throw upstreamError(error);
    try {
      const response = await fetchWithSocketRetry(fallback, {
        headers: { Accept: "image/avif,image/webp,image/png,image/jpeg", "User-Agent": "SHREI/1.0 (MangaDex integration)" },
        redirect: "error",
        signal: AbortSignal.timeout(20000),
      });
      if (!response.ok) {
        throw new MangaDexError("MangaDex's verified uploads host could not serve this page.", { status: 502, code: `MANGADEX_UPLOAD_HTTP_${response.status}` });
      }
      return response;
    } catch (fallbackError) {
      throw upstreamError(fallbackError);
    }
  }
}

function imageContentType(response) {
  const type = (response.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
  if (!["image/jpeg", "image/png", "image/webp", "image/avif"].includes(type)) {
    throw new MangaDexError("MangaDex did not return a supported page image.", { status: 502, code: "MANGADEX_INVALID_IMAGE_TYPE" });
  }
  const length = Number(response.headers.get("content-length"));
  if (Number.isFinite(length) && length > PAGE_MAX_BYTES) {
    throw new MangaDexError("The MangaDex page exceeds the 25 MB reader limit.", { status: 413, code: "MANGADEX_IMAGE_TOO_LARGE" });
  }
  return type;
}

async function readImageBounded(response) {
  const type = imageContentType(response);
  const reader = response.body?.getReader();
  if (!reader) throw new MangaDexError("MangaDex returned an empty chapter page.", { status: 502, code: "MANGADEX_EMPTY_IMAGE" });
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      const chunk = Buffer.from(part.value);
      size += chunk.length;
      if (size > PAGE_MAX_BYTES) {
        await reader.cancel();
        throw new MangaDexError("The MangaDex page exceeds the 25 MB reader limit.", { status: 413, code: "MANGADEX_IMAGE_TOO_LARGE" });
      }
      chunks.push(chunk);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = Buffer.concat(chunks);
  const validSignature = type === "image/jpeg"
    ? bytes.length > 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
    : type === "image/png"
      ? bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
      : type === "image/webp"
        ? bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP"
        : bytes.length >= 12 && bytes.toString("ascii", 4, 8) === "ftyp";
  if (!validSignature) {
    throw new MangaDexError("The MangaDex chapter page did not contain a valid image.", { status: 502, code: "MANGADEX_INVALID_IMAGE" });
  }
  return { type, bytes };
}

function byteLimit(maxBytes) {
  let bytes = 0;
  return new Transform({
    transform(chunk, encoding, callback) {
      bytes += chunk.length;
      if (bytes > maxBytes) callback(new MangaDexError("The MangaDex page exceeds the 25 MB reader limit.", { status: 413, code: "MANGADEX_IMAGE_TOO_LARGE" }));
      else callback(null, chunk);
    },
  });
}

async function fetchCover(mangaId, fileName, size = 256) {
  if (!validUuid(mangaId) || !/^[\w.-]+$/.test(fileName) || fileName.includes("..")) {
    throw new MangaDexError("This MangaDex cover is unavailable.", { status: 404, code: "MANGADEX_COVER_UNAVAILABLE" });
  }
  const coverName = size === 512 ? `${fileName}.512.jpg` : `${fileName}.256.jpg`;
  const url = new URL(`/covers/${mangaId}/${encodeURIComponent(coverName)}`, UPLOADS_BASE);
  const response = await fetchWithSocketRetry(url, {
    headers: { Accept: "image/jpeg,image/webp,image/png", "User-Agent": "SHREI/1.0 (MangaDex integration)" },
    redirect: "error",
    signal: AbortSignal.timeout(15000),
  }).catch((error) => { throw upstreamError(error); });
  if (!response.ok) throw new MangaDexError("The MangaDex cover could not be loaded.", { status: 502, code: `MANGADEX_COVER_HTTP_${response.status}` });
  return response;
}

router.get("/genres", async (req, res) => {
  try {
    const tags = await getGenres();
    return res.json({ success: true, data: tags.genres });
  } catch (error) {
    return sendError(res, error, "MangaDex genres request");
  }
});

router.get("/", async (req, res) => {
  const page = req.query.page === undefined ? 1 : Number(req.query.page);
  const requestedPerPage = req.query.perPage === undefined ? 15 : Number(req.query.perPage);
  if (!Number.isInteger(page) || page < 1 || !Number.isInteger(requestedPerPage) || requestedPerPage < 10 || requestedPerPage > 15) {
    return res.status(400).json({ success: false, message: "page must be positive and perPage must be between 10 and 15." });
  }
  try {
    const params = {
      limit: requestedPerPage,
      offset: (page - 1) * requestedPerPage,
      "contentRating[]": ["safe"],
      "availableTranslatedLanguage[]": ["en"],
      "includes[]": ["cover_art", "author", "artist"],
      ...normalizeSort(String(req.query.sort || "popular")),
    };
    const title = String(req.query.search || "").trim().slice(0, 100);
    if (title) params.title = title;

    const genre = String(req.query.genre || "").trim();
    if (genre && genre !== "all") {
      const genres = await getGenres();
      const tagId = genres.idsByName.get(genre.toLowerCase());
      if (!tagId) return res.status(400).json({ success: false, message: "Choose a valid MangaDex genre." });
      params["includedTags[]"] = [tagId];
      params.includedTagsMode = "AND";
    }
    const year = req.query.year === undefined || req.query.year === "all" ? null : Number(req.query.year);
    if (year !== null && (!Number.isInteger(year) || year < 1900 || year > new Date().getFullYear() + 2)) {
      return res.status(400).json({ success: false, message: "Choose a valid manga publication year." });
    }
    if (year) params.year = year;
    const status = String(req.query.status || "");
    const mangaStatuses = { Ongoing: "ongoing", Completed: "completed", "On hiatus": "hiatus", Cancelled: "cancelled" };
    if (Object.hasOwn(mangaStatuses, status)) params["status[]"] = [mangaStatuses[status]];

    const response = await getJson("/manga", params);
    const data = (response.data || [])
      .filter((item) => validUuid(item.id) && localizedText(item.attributes?.title))
      .map(mapManga);
    return res.json({
      success: true,
      data,
      pagination: {
        currentPage: page,
        perPage: requestedPerPage,
        hasNextPage: page * requestedPerPage < response.total,
        total: Number(response.total) || 0,
      },
    });
  } catch (error) {
    return sendError(res, error, "MangaDex manga catalogue");
  }
});

router.get("/:mangaId/cover/:fileName", async (req, res) => {
  const size = Number(req.query.size) === 512 ? 512 : 256;
  try {
    const response = await fetchCover(req.params.mangaId, req.params.fileName, size);
    const type = (response.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (!["image/jpeg", "image/png", "image/webp"].includes(type)) {
      await response.body?.cancel();
      return res.status(502).json({ success: false, message: "MangaDex returned an invalid cover image." });
    }
    res.setHeader("Content-Type", type);
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.setHeader("X-Content-Type-Options", "nosniff");
    await pipeline(Readable.fromWeb(response.body), byteLimit(PAGE_MAX_BYTES), res);
    return undefined;
  } catch (error) {
    if (res.headersSent) {
      res.destroy(error);
      return undefined;
    }
    return sendError(res, error, "MangaDex cover request");
  }
});

router.get("/:mangaId/chapters", async (req, res) => {
  const mangaId = req.params.mangaId;
  if (!validUuid(mangaId)) return res.status(400).json({ success: false, message: "A valid MangaDex manga id is required." });
  try {
    const feed = await fetchChapterFeed(mangaId);
    return res.json({
      success: true,
      data: feed.data,
      pagination: { currentPage: 1, perPage: feed.limit, total: feed.total, hasNextPage: feed.hasMore },
      message: feed.hasMore ? "Showing the first 500 English chapters; more are available on MangaDex." : undefined,
    });
  } catch (error) {
    return sendError(res, error, "MangaDex chapter list");
  }
});

router.get("/:mangaId/chapters/:chapterId", async (req, res) => {
  const { mangaId, chapterId } = req.params;
  if (!validUuid(mangaId) || !validUuid(chapterId)) {
    return res.status(400).json({ success: false, message: "Valid MangaDex manga and chapter ids are required." });
  }
  if (removed(chapterId)) return res.status(410).json({ success: false, message: "This chapter was removed at the scanlation group's request." });
  try {
    const feed = await fetchChapterFeed(mangaId);
    const index = feed.data.findIndex((chapter) => chapter.chapterId === chapterId);
    if (index < 0) return res.status(404).json({ success: false, message: "This English chapter is not available in the MangaDex feed." });

    const chapter = feed.data[index];
    const source = await getAtHome(mangaId, chapterId);
    const firstImage = await fetchChapterImage(source, source.files[0]);
    const verified = await readImageBounded(firstImage);
    const data = {
      ...chapter,
      canRead: true,
      verificationStatus: "first-page-verified",
      verifiedAt: new Date().toISOString(),
      pageCount: source.files.length,
      pages: source.files.map((file, pageIndex) => ({
        pageNumber: pageIndex + 1,
        imagePath: `/manga/${mangaId}/chapters/${chapterId}/pages/${pageIndex + 1}`,
      })),
      previousChapterId: feed.data[index - 1]?.chapterId || null,
      nextChapterId: feed.data[index + 1]?.chapterId || null,
      credits: {
        provider: "MangaDex",
        groupName: chapter.groupName,
        groupUrl: chapter.groupId ? `${MANGADEX_WEB}/group/${chapter.groupId}` : MANGADEX_WEB,
        mangaUrl: `${MANGADEX_WEB}/title/${mangaId}`,
        notice: "The first page was verified. Remaining pages load from MangaDex as you read.",
      },
      firstPage: { contentType: verified.type, bytes: verified.bytes.length },
      canDownload: false,
    };
    return res.json({ success: true, data });
  } catch (error) {
    return sendError(res, error, "MangaDex chapter verification");
  }
});

router.get("/:mangaId/chapters/:chapterId/pages/:pageNumber", async (req, res) => {
  const { mangaId, chapterId } = req.params;
  const pageNumber = Number(req.params.pageNumber);
  if (!validUuid(mangaId) || !validUuid(chapterId) || !Number.isInteger(pageNumber) || pageNumber < 1) {
    return res.status(400).json({ success: false, message: "A valid MangaDex page reference is required." });
  }
  if (removed(chapterId)) return res.status(410).json({ success: false, message: "This chapter was removed at the scanlation group's request." });
  try {
    const source = await getAtHome(mangaId, chapterId);
    const filename = source.files[pageNumber - 1];
    if (!filename) return res.status(404).json({ success: false, message: "This MangaDex page does not exist." });
    const response = await fetchChapterImage(source, filename);
    const contentType = imageContentType(response);
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    await pipeline(Readable.fromWeb(response.body), byteLimit(PAGE_MAX_BYTES), res);
    return undefined;
  } catch (error) {
    if (res.headersSent) {
      res.destroy(error);
      return undefined;
    }
    return sendError(res, error, "MangaDex chapter page");
  }
});

router.get("/:mangaId", async (req, res) => {
  const mangaId = req.params.mangaId;
  if (!validUuid(mangaId)) return res.status(400).json({ success: false, message: "A valid MangaDex manga id is required." });
  try {
    const response = await getJson(`/manga/${mangaId}`, {
      "includes[]": ["cover_art", "author", "artist"],
    });
    if (!validUuid(response.data?.id) || !localizedText(response.data.attributes?.title)) {
      return res.status(404).json({ success: false, message: "MangaDex title not found." });
    }
    return res.json({ success: true, data: mapManga(response.data) });
  } catch (error) {
    return sendError(res, error, "MangaDex manga details");
  }
});

module.exports = router;
