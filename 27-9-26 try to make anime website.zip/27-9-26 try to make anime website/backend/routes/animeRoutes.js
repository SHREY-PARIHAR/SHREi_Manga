const express = require("express");
const mongoose = require("mongoose");
const Anime = require("../models/anime");
const AnimeCatalogPage = require("../models/animeCatalogPage");
const requestAniList = require("../utils/anilistClient");

const router = express.Router();
const DEFAULT_PER_PAGE = 50;
const MAX_PER_PAGE = 50;
const PAGE_CACHE_TTL_MS = 60 * 60 * 1000;
const ANILIST_MEDIA_FIELDS = `
      id
      title { romaji english }
      description(asHtml: false)
      coverImage { extraLarge large }
      bannerImage
      genres
      episodes
      averageScore
      popularity
      status
      format
      startDate { year month }
      studios(isMain: true) { nodes { name } }
      externalLinks { site url type isDisabled }
      relations { edges { relationType(version: 2) node { id type title { english romaji } } } }
`;
const SORTS = {
  popular: ["POPULARITY_DESC"],
  rating: ["SCORE_DESC"],
  latest: ["START_DATE_DESC"],
  az: ["TITLE_ROMAJI"],
};
const STATUSES = {
  Ongoing: "RELEASING",
  Completed: "FINISHED",
  Upcoming: "NOT_YET_RELEASED",
};

function mapAniListAnime(item, index) {
  const month = item.startDate?.month;
  const season = month
    ? ["Winter", "Winter", "Spring", "Spring", "Spring", "Summer", "Summer", "Summer", "Fall", "Fall", "Fall", "Winter"][month - 1]
    : "Unknown";
  const status = {
    FINISHED: "Completed",
    RELEASING: "Ongoing",
    NOT_YET_RELEASED: "Upcoming",
    CANCELLED: "Completed",
  }[item.status] || "Completed";
  const seenProviderNames = new Set();
  const officialProviders = (item.externalLinks || []).flatMap((link) => {
    if (link.type !== "STREAMING" || link.isDisabled || !link.site || !link.url) return [];
    try {
      const url = new URL(link.url);
      const name = link.site.trim();
      const key = name.toLowerCase();
      if (url.protocol !== "https:" || url.username || url.password || !name || seenProviderNames.has(key)) return [];
      seenProviderNames.add(key);
      return [{ name, url: url.href, accessType: "official" }];
    } catch {
      return [];
    }
  });

  return {
    sourceId: item.id,
    title: item.title.english || item.title.romaji || item.title.native,
    description: item.description || "",
    poster: item.coverImage.extraLarge || item.coverImage.large || "",
    banner: item.bannerImage || "",
    genres: item.genres || [],
    language: [],
    type: item.format === "MOVIE" ? "Movie" : "Series",
    year: item.startDate?.year || undefined,
    season,
    studio: (item.studios?.nodes || []).map((studio) => studio.name).join(", "),
    status,
    totalEpisodes: item.episodes || 0,
    rating: item.averageScore ? Number((item.averageScore / 10).toFixed(1)) : 0,
    popularity: Number(item.popularity) || 0,
    featured: index < 5,
    adaptations: (item.relations?.edges || [])
      .filter((edge) => edge.node?.id && edge.node?.type && edge.node?.title)
      .map((edge) => ({
        sourceId: edge.node.id,
        type: edge.node.type,
        title: edge.node.title.english || edge.node.title.romaji || "Untitled",
        relation: edge.relationType || "RELATED",
      })),
    ...(officialProviders.length ? { officialProviders } : {}),
  };
}

function normalizeFilters(input) {
  const search = String(input.search || "").trim().toLowerCase();
  const genre = String(input.genre || "").trim();
  const year = input.year && input.year !== "all" ? Number(input.year) : 0;
  const status = STATUSES[input.status] ? input.status : "";
  const sort = SORTS[input.sort] ? input.sort : "popular";

  return {
    search,
    genre: genre && genre !== "all" ? genre : "",
    year: Number.isInteger(year) && year > 0 ? year : 0,
    status,
    sort,
  };
}

function cacheKey(page, perPage, filters) {
  return { page, perPage, ...filters };
}

function buildAniListQuery(filters) {
  const variableDefinitions = ["$page: Int!", "$perPage: Int!", "$sort: [MediaSort!]!"];
  const mediaArguments = ["type: ANIME", "sort: $sort", "isAdult: false"];
  if (filters.search) {
    variableDefinitions.push("$search: String");
    mediaArguments.push("search: $search");
  }
  if (filters.genre) {
    variableDefinitions.push("$genre: String");
    mediaArguments.push("genre: $genre");
  }
  if (filters.year) {
    variableDefinitions.push("$seasonYear: Int");
    mediaArguments.push("seasonYear: $seasonYear");
  }
  if (filters.status) {
    variableDefinitions.push("$status: MediaStatus");
    mediaArguments.push("status: $status");
  }

  return `query (${variableDefinitions.join(", ")}) {
    Page(page: $page, perPage: $perPage) {
      pageInfo { total hasNextPage }
      media(${mediaArguments.join(", ")}) { ${ANILIST_MEDIA_FIELDS} }
    }
  }`;
}

async function fetchAniListPage(page, perPage, filters) {
  const variables = { page, perPage, sort: SORTS[filters.sort] };
  if (filters.search) variables.search = filters.search;
  if (filters.genre) variables.genre = filters.genre;
  if (filters.year) variables.seasonYear = filters.year;
  if (filters.status) variables.status = STATUSES[filters.status];

  const data = await requestAniList(buildAniListQuery(filters), variables);
  const pageData = data.Page;
  if (!pageData?.pageInfo || !Array.isArray(pageData.media)) {
    throw Object.assign(new Error("AniList returned an invalid catalogue page."), { code: "ANILIST_INVALID_RESPONSE" });
  }
  const seenIds = new Set();
  const anime = pageData.media
    .filter((item) => {
      if (seenIds.has(item.id)) return false;
      seenIds.add(item.id);
      return true;
    })
    .map((item, index) => mapAniListAnime(item, (page - 1) * perPage + index));
  return {
    anime,
    total: pageData.pageInfo.total,
    hasNextPage: pageData.pageInfo.hasNextPage,
  };
}

async function getCachedPage(page, perPage, filters) {
  const query = cacheKey(page, perPage, filters);
  let cache = await AnimeCatalogPage.findOne(query).lean();

  if (!cache && !filters.search && !filters.genre && !filters.year && !filters.status && filters.sort === "popular") {
    cache = await AnimeCatalogPage.findOne({
      page,
      perPage,
      search: { $in: ["", null] },
      genre: { $in: ["", null] },
      year: { $in: [0, null] },
      status: { $in: ["", null] },
      sort: { $in: ["popular", null] },
    }).lean();
    if (cache) {
      await AnimeCatalogPage.updateOne({ _id: cache._id }, { $set: filters });
    }
  }

  if (!cache || Date.now() - cache.cachedAt.getTime() >= PAGE_CACHE_TTL_MS) return null;

  const records = cache.sourceIds.length
    ? await Anime.find({ sourceId: { $in: cache.sourceIds } }).lean()
    : [];
  if (records.length !== cache.sourceIds.length) return null;

  const bySourceId = new Map(records.map((record) => [record.sourceId, record]));
  return {
    data: cache.sourceIds.map((sourceId) => bySourceId.get(sourceId)),
    pagination: {
      currentPage: page,
      perPage,
      hasNextPage: cache.hasNextPage,
      total: cache.total,
    },
  };
}

async function getStaleCachedPage(page, perPage, filters) {
  const cache = await AnimeCatalogPage.findOne(cacheKey(page, perPage, filters)).lean();
  if (!cache) return null;
  const records = cache.sourceIds.length
    ? await Anime.find({ sourceId: { $in: cache.sourceIds } }).lean()
    : [];
  if (records.length !== cache.sourceIds.length) return null;

  const bySourceId = new Map(records.map((record) => [record.sourceId, record]));
  return {
    data: cache.sourceIds.map((sourceId) => bySourceId.get(sourceId)),
    pagination: {
      currentPage: page,
      perPage,
      hasNextPage: cache.hasNextPage,
      total: cache.total,
    },
    cachedFallback: true,
  };
}

function mongoFilter(filters) {
  const query = {};
  if (filters.search) {
    const escaped = filters.search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    query.$or = [{ title: { $regex: escaped, $options: "i" } }, { genres: { $regex: escaped, $options: "i" } }];
  }
  if (filters.genre) query.genres = filters.genre;
  if (filters.year) query.year = filters.year;
  if (filters.status) query.status = filters.status;
  return query;
}

async function getMongoFallback(page, perPage, filters) {
  const sort = filters.sort === "az"
    ? { title: 1 }
    : filters.sort === "latest"
      ? { year: -1 }
      : filters.sort === "popular"
        ? { popularity: -1, _id: 1 }
        : { rating: -1 };
  const data = await Anime.find(mongoFilter(filters))
    .sort(sort)
    .skip((page - 1) * perPage)
    .limit(perPage)
    .lean();
  return {
    data,
    pagination: { currentPage: page, perPage, hasNextPage: false, total: data.length },
    cachedFallback: true,
  };
}

async function cacheAniListPage(page, perPage, filters) {
  const sourcePage = await fetchAniListPage(page, perPage, filters);
  const sourceIds = sourcePage.anime.map((item) => item.sourceId);

  if (sourcePage.anime.length) {
    await Anime.bulkWrite(sourcePage.anime.map((item) => ({
      updateOne: {
        filter: { sourceId: item.sourceId },
        update: { $set: item },
        upsert: true,
      },
    })));
  }

  await AnimeCatalogPage.findOneAndUpdate(
    cacheKey(page, perPage, filters),
    {
      $set: {
        sourceIds,
        total: sourcePage.total,
        hasNextPage: sourcePage.hasNextPage,
        cachedAt: new Date(),
      },
    },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  const records = sourceIds.length
    ? await Anime.find({ sourceId: { $in: sourceIds } }).lean()
    : [];
  const bySourceId = new Map(records.map((record) => [record.sourceId, record]));
  return {
    data: sourceIds.map((sourceId) => bySourceId.get(sourceId)).filter(Boolean),
    pagination: {
      currentPage: page,
      perPage,
      hasNextPage: sourcePage.hasNextPage,
      total: sourcePage.total,
    },
  };
}

// Get a page of anime
router.get("/genres", async (req, res) => {
  try {
    const data = await requestAniList("query { GenreCollection }");
    if (!Array.isArray(data.GenreCollection)) {
      throw Object.assign(new Error("AniList returned invalid genres."), { code: "ANILIST_INVALID_RESPONSE" });
    }
    res.json({ success: true, data: data.GenreCollection });
  } catch (error) {
    console.error("Anime genres request failed:", error.code || error.name || "request error");
    res.status(502).json({ success: false, message: "Anime genres are temporarily unavailable." });
  }
});

router.get("/", async (req, res) => {
  try {
    const page = req.query.page === undefined ? 1 : Number(req.query.page);
    const perPage = req.query.perPage === undefined ? DEFAULT_PER_PAGE : Number(req.query.perPage);
    if (!Number.isInteger(page) || page < 1 || !Number.isInteger(perPage) || perPage < 1 || perPage > MAX_PER_PAGE) {
      return res.status(400).json({
        success: false,
        message: `page must be a positive integer and perPage must be between 1 and ${MAX_PER_PAGE}.`,
      });
    }

    const filters = normalizeFilters(req.query);
    let result;
    if (mongoose.connection.readyState !== 1) {
      const sourcePage = await fetchAniListPage(page, perPage, filters);
      result = {
        data: sourcePage.anime,
        pagination: {
          currentPage: page,
          perPage,
          hasNextPage: sourcePage.hasNextPage,
          total: sourcePage.total,
        },
      };
    } else {
      result = await getCachedPage(page, perPage, filters);
      if (!result) {
        try {
          result = await cacheAniListPage(page, perPage, filters);
        } catch (error) {
          result = await getStaleCachedPage(page, perPage, filters)
            || await getMongoFallback(page, perPage, filters);
        }
      }
    }

    res.json({
      success: true,
      data: result.data.map((item) => ({
        ...item,
        playbackSources: Array.isArray(item.playbackSources) ? item.playbackSources : [],
      })),
      pagination: result.pagination,
      cachedFallback: Boolean(result.cachedFallback),
    });
  } catch (error) {
    console.error("Anime catalogue request failed:", error.code || error.name || "request error");
    res.status(502).json({
      success: false,
      message: "The anime catalogue is temporarily unavailable. Please try again.",
    });
  }
});

// Add new anime
router.post("/", async (req, res) => {
  try {
    const animeData = { ...req.body };
    delete animeData.playbackSources;
    const anime = await Anime.create(animeData);

    res.status(201).json({
      success: true,
      data: anime,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
});

module.exports = router;